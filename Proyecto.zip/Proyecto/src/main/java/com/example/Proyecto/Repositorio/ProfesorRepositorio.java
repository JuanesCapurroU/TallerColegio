package com.example.Proyecto.Repositorio;

import com.example.Proyecto.Modelo.Profesores;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepositorio extends JpaRepository<Profesores, Integer> {
}
